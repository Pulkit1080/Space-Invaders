﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

 [System.Serializable]
public class MapLimits
{
    public int minimumX;
    public int maximumX;
    public int minimumY;
    public int maximumY;
}
